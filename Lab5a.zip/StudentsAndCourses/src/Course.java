
public class Course {
	
	private String courseCode;
	private String courseNumber;
	private String courseDescription;
	private int courseCredits;
	
	Course(String courseCode, String courseNumber, String courseDescription, int credits)
	{
		this.courseCode = courseCode;
		this.courseNumber = courseNumber;
		this.courseDescription = courseDescription;
		this.courseCredits = credits;
	}

	
	public String toString()
	{
		return "Course Code: " + this.courseCode + "\n" +
			   "Course Numnber: " + this.courseNumber + "\n" +
			   "Course Description: " + this.courseDescription + "\n"+
			   "Course Credits: "+this.courseCredits;
	}

	public void setDesc (String desc)
	{
		this.courseDescription = desc;
	}

}

