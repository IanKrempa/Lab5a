import java.util.ArrayList; 

public class Lab5Test {

	public static void main(String[] args) {
		System.out.println("Lab 5");

		// Instantiate Student List Class

		StudentList cs176List = new StudentList();
		ArrayList<Registration> courses = new ArrayList<Registration>();
		

		// instantiate a student
		Student s1 = new Student("Ahmed, Saahil", "1219200", "s1219200@monmouth.edu", "CS", 2, "E. Cesario", 1.0, 2022, courses);
		Student s2 = new Student("Berardis, Anthony William", "1297598", "s1297598@monmouth.edu", "CS", 2, "R. Scherl",1.0, 2022,courses);
		Student s3 = new Student("Clappsy, Thomas V", "1212339", "s1212339@monmouth.edu", "CS", 2, "J. Kretsch", 1.0,2022, courses);
		
		Course c1 = new Course("CS", "175", "Description", 3);
		Course c2 = new Course("CS", "176", "Description", 3);
		Course c3 = new Course("CS", "175L", "Description", 1);
		Course c4 = new Course("CS", "176L", "Description", 1);
		
		
		Registration r1 = new Registration(c1, 0.0);
		Registration r2 = new Registration(c2, 0.0);
		Registration r3 = new Registration(c3, 0.0);
		Registration r4 = new Registration(c4, 0.0);
		
		r1.setGrade(50.0);
		r2.setGrade(15.0);
		
		c1.setDesc("Computer Science 175");
		c2.setDesc("Computer Science 176");
		c3.setDesc("Computer Science 175 Lab");
		c4.setDesc("Computer Science 176 Lab");

		cs176List.addStudent(s1);
		cs176List.addStudent(s2);
		cs176List.addStudent(s3);
		
		s1.addRegistration(r1);
		s1.addRegistration(r2);
		
		s2.addRegistration(r1);
		s2.addRegistration(r2);
		s2.addRegistration(r3);
		
		s3.addRegistration(r4);
		
		
		
		cs176List.listStudents();
		
		
		
		
	}
}
