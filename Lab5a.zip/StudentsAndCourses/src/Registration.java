
public class Registration 
{

	private Course course;
	private double grade = 0.00;
	
	Registration (Course c, double g)
	{
		this.course = c;
		this.grade = g;
	}
	
	public void setGrade(double newgrade)
	{
		this.grade = newgrade;
	}
	
	public double getGrade()
	{
		return this.grade;
	}
	
	
	public String toString()
	{
		return ("Course: \n\n" + this.course.toString() + "\nGrade: " + this.grade);
	}
	
}
